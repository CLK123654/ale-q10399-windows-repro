import { defineConfig, devices } from 'playwright/test';
import path from 'node:path';

const inputRoot = path.resolve(process.env.ALE_INPUT_ROOT ?? process.cwd());
const port = Number(process.env.ALE_TASK_PORT);
if (!Number.isInteger(port) || port < 1) throw new Error('ALE_TASK_PORT缺失');

export default defineConfig({
  testDir: './tests',
  workers: 1,
  fullyParallel: false,
  retries: 0,
  timeout: 60_000,
  reporter: [['line']],
  outputDir: path.join(inputRoot, '.playwright-artifacts'),
  use: {
    baseURL: `http://127.0.0.1:${port}`,
    trace: 'retain-on-failure',
    screenshot: 'only-on-failure'
  },
  projects: [{ name: 'chromium', use: { ...devices['Desktop Chrome'] } }],
  webServer: {
    command: 'node scripts/static_server.mjs',
    cwd: inputRoot,
    env: { PORT: String(port) },
    url: `http://127.0.0.1:${port}`,
    reuseExistingServer: false,
    timeout: 15_000
  }
});
