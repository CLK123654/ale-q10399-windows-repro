import { test, expect, type Page } from 'playwright/test';
import fs from 'node:fs/promises';
import fsSync from 'node:fs';
import path from 'node:path';

type SaveScenario = {
  scenario_id: string;
  user_id: string;
  target_email_digest: string;
  target_push_alerts: string;
  target_sms_alerts: string;
  target_personalized_deals: string;
  consent_checked: string;
  server_status: string;
};

const inputRoot = path.resolve(process.env.ALE_INPUT_ROOT ?? process.cwd());
const reportsDir = path.join(inputRoot, 'output', 'reports');
const profiles = JSON.parse(fsSync.readFileSync(path.join(inputRoot, 'fixtures', 'profiles.json'), 'utf8'));
const policy = JSON.parse(fsSync.readFileSync(path.join(inputRoot, 'fixtures', 'consent_policy.json'), 'utf8'));
const scenarios = parseCsv(fsSync.readFileSync(path.join(inputRoot, 'fixtures', 'save_scenarios.csv'), 'utf8'));
const controls = ['email_digest', 'push_alerts', 'sms_alerts', 'personalized_deals'];
const externalUrls: string[] = [];

function parseCsv(text: string): SaveScenario[] {
  const [header, ...lines] = text.trim().split(/\r?\n/);
  const keys = header.split(',');
  return lines.map((line) => Object.fromEntries(line.split(',').map((value, index) => [keys[index], value])) as SaveScenario);
}

function asBoolean(value: string) { return value === 'true'; }
function csvEscape(value: unknown) {
  const text = String(value ?? '');
  return /[",\r\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
}
function toCsv(headers: string[], rows: Record<string, unknown>[]) {
  return [headers.join(','), ...rows.map((row) => headers.map((header) => csvEscape(row[header])).join(','))].join('\n') + '\n';
}
function expectedOutcome(scenario: SaveScenario, profile: any) {
  const target = Object.fromEntries(controls.map((control) => [control, asBoolean(scenario[`target_${control}` as keyof SaveScenario])]));
  const rules = policy.rollback_rules;
  if (rules.sms_requires_verified_phone && target.sms_alerts && !profile.phone_verified) {
    return { target, result: 'blocked_before_save', reason: 'sms_requires_verified_phone', message: policy.status_messages.sms_requires_verified_phone };
  }
  if (rules.eu_personalized_deals_requires_explicit_consent
      && rules.explicit_consent_regions.includes(profile.region)
      && target.personalized_deals
      && !asBoolean(scenario.consent_checked)) {
    return { target, result: 'blocked_before_save', reason: 'eu_consent_required', message: policy.status_messages.eu_consent_required };
  }
  if (Number(scenario.server_status) === rules.stale_revision_status) {
    return { target, result: 'rolled_back_after_save', reason: 'stale_revision', message: policy.status_messages.stale_revision };
  }
  return { target, result: 'saved', reason: 'saved', message: policy.status_messages.saved };
}
async function installRoutes(page: Page) {
  page.on('request', (request) => {
    const hostname = new URL(request.url()).hostname;
    if (hostname !== '127.0.0.1' && hostname !== 'localhost') externalUrls.push(request.url());
  });
  await page.route(`**${policy.profiles_endpoint}`, (route) => route.fulfill({ status: 200, json: profiles }));
  await page.route(`**${policy.policy_endpoint}`, (route) => route.fulfill({ status: 200, json: policy }));
}

test.beforeAll(async () => {
  await fs.rm(reportsDir, { recursive: true, force: true });
  await fs.mkdir(reportsDir, { recursive: true });
});

test('subscription consent, revision, rollback and keyboard contracts', async ({ browser }) => {
  const stateRows: Record<string, unknown>[] = [];
  const rollbackRows: Record<string, unknown>[] = [];
  const focusRows: Record<string, unknown>[] = [];

  const focusContext = await browser.newContext();
  const focusPage = await focusContext.newPage();
  await installRoutes(focusPage);
  await focusPage.route(`**${policy.save_endpoint}`, (route) => route.fulfill({ status: 200, json: { ok: true } }));
  await focusPage.goto('/');
  for (let index = 0; index < policy.keyboard_contract.length; index += 1) {
    const testId = policy.keyboard_contract[index];
    const accessible = focusPage.getByRole(policy.keyboard_roles[testId], { name: policy.keyboard_names[testId], exact: true });
    await focusPage.keyboard.press('Tab');
    await expect(accessible).toBeFocused();
    focusRows.push({
      order_index: index + 1,
      locator: `[data-testid=${testId}]`,
      expected_role: policy.keyboard_roles[testId],
      expected_name: policy.keyboard_names[testId],
      focused: true
    });
  }
  await focusPage.getByTestId('email_digest').check();
  await focusPage.getByRole(policy.keyboard_roles.undo_changes, { name: policy.keyboard_names.undo_changes, exact: true }).focus();
  await focusPage.keyboard.press('Enter');
  await expect(focusPage.getByTestId('email_digest')).not.toBeChecked();
  await focusContext.close();

  for (const scenario of scenarios) {
    const context = await browser.newContext();
    const page = await context.newPage();
    const profile = profiles.find((candidate: any) => candidate.user_id === scenario.user_id);
    expect(profile).toBeTruthy();
    const expected = expectedOutcome(scenario, profile);
    const scenarioRequests: Array<{ headers: Record<string, string>; body: Record<string, unknown> }> = [];
    await installRoutes(page);
    await page.route(`**${policy.save_endpoint}`, async (route) => {
      const request = { headers: route.request().headers(), body: route.request().postDataJSON() as Record<string, unknown> };
      scenarioRequests.push(request);
      const status = Number(scenario.server_status);
      await route.fulfill({ status, json: { ok: status >= 200 && status < 300 } });
    });
    await page.goto('/');
    await page.getByTestId('profile-select').selectOption(scenario.user_id);
    for (const control of controls) await page.getByTestId(control).setChecked(expected.target[control]);
    await page.getByTestId('consent_checkbox').setChecked(asBoolean(scenario.consent_checked));
    await page.getByRole(policy.keyboard_roles.save_preferences, { name: policy.keyboard_names.save_preferences, exact: true }).click();
    await expect(page.getByTestId(policy.aria_live_region)).toHaveText(expected.message);

    const requestSent = scenarioRequests.length === 1;
    expect(requestSent).toBe(expected.result !== 'blocked_before_save');
    let requestRevision = '';
    let requestBodyMatch = false;
    if (requestSent) {
      const request = scenarioRequests[0];
      requestRevision = request.headers[policy.revision_header] ?? '';
      requestBodyMatch = request.body.user_id === scenario.user_id
        && controls.every((control) => request.body[control] === expected.target[control]);
      expect(requestRevision).toBe(profile.revision);
      expect(requestBodyMatch).toBe(true);
    }
    const expectedFinal = expected.result === 'saved'
      ? expected.target
      : Object.fromEntries(controls.map((control) => [control, Boolean(profile[`current_${control}`])]));
    const finalState: Record<string, boolean> = {};
    for (const control of controls) {
      finalState[control] = await page.getByTestId(control).isChecked();
      expect(finalState[control]).toBe(expectedFinal[control]);
    }
    stateRows.push({
      scenario_id: scenario.scenario_id,
      user_id: scenario.user_id,
      region: profile.region,
      request_sent: requestSent,
      request_revision: requestRevision,
      request_body_match: requestSent ? requestBodyMatch : '',
      server_status: scenario.server_status,
      final_email_digest: finalState.email_digest,
      final_push_alerts: finalState.push_alerts,
      final_sms_alerts: finalState.sms_alerts,
      final_personalized_deals: finalState.personalized_deals,
      result: expected.result,
      reason: expected.reason,
      aria_message: expected.message
    });
    if (expected.result !== 'saved') rollbackRows.push({
      scenario_id: scenario.scenario_id,
      user_id: scenario.user_id,
      rollback_reason: expected.reason,
      request_sent: requestSent,
      server_status: scenario.server_status,
      restored_to_previous: controls.every((control) => finalState[control] === Boolean(profile[`current_${control}`])),
      aria_message: expected.message
    });
    await context.close();
  }

  expect(externalUrls).toEqual([]);

  await fs.writeFile(path.join(reportsDir, 'settings_state_report.csv'), toCsv(
    ['scenario_id', 'user_id', 'region', 'request_sent', 'request_revision', 'request_body_match', 'server_status', 'final_email_digest', 'final_push_alerts', 'final_sms_alerts', 'final_personalized_deals', 'result', 'reason', 'aria_message'], stateRows
  ));
  await fs.writeFile(path.join(reportsDir, 'save_rollback_report.csv'), toCsv(
    ['scenario_id', 'user_id', 'rollback_reason', 'request_sent', 'server_status', 'restored_to_previous', 'aria_message'], rollbackRows
  ));
  await fs.writeFile(path.join(reportsDir, 'keyboard_focus_report.csv'), toCsv(
    ['order_index', 'locator', 'expected_role', 'expected_name', 'focused'], focusRows
  ));
});
