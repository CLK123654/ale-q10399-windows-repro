# 订阅设置发布检查材料

app/subscription_settings.html与app/subscription_settings.js组成待检查的本地页面，格式参考常见订阅偏好中心并使用虚构接口。fixtures/profiles.json是脱敏演练用户资料，fixtures/consent_policy.json是发布团队制定的同意、回滚、文案与键盘合同，fixtures/save_scenarios.csv是本次发布旅程。三份fixture都必须由浏览器测试读取。

starter/tests/subscription_settings.spec.ts提供测试起点。完成版写入output/tests/subscription_settings.spec.ts，Playwright配置写入output/playwright.config.ts。scripts/static_server.mjs负责本机页面服务，tools/run-task.mjs负责调用Playwright并检查声明交付物。

在本目录安装锁定依赖与Chromium后运行npm run process。正式运行只访问本机回环地址，输出写入output目录。
