let profiles = [];
let policy = {};
let current = null;
const controls = ['email_digest', 'push_alerts', 'sms_alerts', 'personalized_deals'];
const byTestId = (id) => document.querySelector(`[data-testid=${id}]`);

function restoreCurrent(message) {
  for (const control of controls) byTestId(control).checked = Boolean(current[`current_${control}`]);
  byTestId('consent_checkbox').checked = false;
  byTestId('settings-status').textContent = message;
}

function loadProfile(userId) {
  current = profiles.find((profile) => profile.user_id === userId);
  restoreCurrent(`${policy.status_messages.loaded_prefix} ${userId}`);
}

async function save() {
  const payload = Object.fromEntries(controls.map((control) => [control, byTestId(control).checked]));
  payload.user_id = current.user_id;
  const rules = policy.rollback_rules;
  if (rules.sms_requires_verified_phone && payload.sms_alerts && !current.phone_verified) {
    restoreCurrent(policy.status_messages.sms_requires_verified_phone);
    return;
  }
  if (rules.eu_personalized_deals_requires_explicit_consent
      && rules.explicit_consent_regions.includes(current.region)
      && payload.personalized_deals
      && !byTestId('consent_checkbox').checked) {
    restoreCurrent(policy.status_messages.eu_consent_required);
    return;
  }
  const response = await fetch(policy.save_endpoint, {
    method: 'PUT',
    headers: { 'content-type': 'application/json', [policy.revision_header]: current.revision },
    body: JSON.stringify(payload)
  });
  if (!response.ok) {
    const message = response.status === rules.stale_revision_status
      ? policy.status_messages.stale_revision
      : policy.status_messages.unexpected_http_status;
    restoreCurrent(message);
    return;
  }
  Object.assign(current, Object.fromEntries(controls.map((control) => [`current_${control}`, payload[control]])));
  byTestId('settings-status').textContent = policy.status_messages.saved;
}

async function boot() {
  profiles = await fetch('/api/subscription/profiles').then((response) => response.json());
  policy = await fetch('/api/subscription/policy').then((response) => response.json());
  const select = byTestId('profile-select');
  for (const profile of profiles) {
    const option = document.createElement('option');
    option.value = profile.user_id;
    option.textContent = `${profile.user_id} ${profile.region}`;
    select.appendChild(option);
  }
  select.onchange = () => loadProfile(select.value);
  byTestId('undo_changes').onclick = () => loadProfile(select.value);
  byTestId('save_preferences').onclick = save;
  loadProfile(profiles[0].user_id);
}

boot();
