import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
const root = path.resolve('app');
http.createServer(async (req, res) => {
  const target = req.url === '/' ? 'subscription_settings.html' : req.url.replace(/^\//, '');
  try { res.end(await fs.readFile(path.join(root, target))); } catch { res.statusCode = 404; res.end('not found'); }
}).listen(process.env.PORT || 4193);
