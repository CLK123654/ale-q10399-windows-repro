import { expect, test } from 'playwright/test';

test('完成订阅同意、保存回滚与键盘焦点检查', async ({ page }) => {
  await page.goto('/');
  await expect(page.getByTestId('profile-select')).toBeVisible();
});
