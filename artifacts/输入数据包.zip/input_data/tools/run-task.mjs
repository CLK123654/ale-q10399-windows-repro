import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import net from 'node:net';
import path from 'node:path';
import process from 'node:process';
import { spawnSync } from 'node:child_process';
import { createRequire } from 'node:module';

const root = process.cwd();
const outputRoot = path.join(root, 'output');
const reportsRoot = path.join(outputRoot, 'reports');
const artifactsRoot = path.join(root, '.playwright-artifacts');
const requiredInputs = [
  'app/subscription_settings.html',
  'app/subscription_settings.js',
  'fixtures/profiles.json',
  'fixtures/consent_policy.json',
  'fixtures/save_scenarios.csv',
  'scripts/static_server.mjs',
  'package.json',
  'README.md'
];
const candidateFiles = ['output/playwright.config.ts', 'output/tests/subscription_settings.spec.ts'];
const reportFiles = [
  'keyboard_focus_report.csv',
  'save_rollback_report.csv',
  'settings_state_report.csv'
];

async function exists(relative) {
  try { await fs.access(path.join(root, relative)); return true; } catch { return false; }
}
async function listFiles(directory, prefix = '') {
  const files = [];
  for (const entry of (await fs.readdir(directory, { withFileTypes: true })).sort((a, b) => a.name.localeCompare(b.name))) {
    if (entry.name === 'output' || entry.name === '.playwright-artifacts') continue;
    const relative = prefix ? `${prefix}/${entry.name}` : entry.name;
    if (entry.isDirectory()) files.push(...await listFiles(path.join(directory, entry.name), relative));
    else files.push(relative);
  }
  return files;
}
async function inputDigest() {
  const hash = crypto.createHash('sha256');
  for (const relative of await listFiles(root)) {
    hash.update(relative).update('\0').update(await fs.readFile(path.join(root, relative))).update('\0');
  }
  return hash.digest('hex');
}
async function cleanGenerated() {
  await fs.rm(reportsRoot, { recursive: true, force: true });
  await fs.rm(artifactsRoot, { recursive: true, force: true });
}
async function freePort() {
  return await new Promise((resolve, reject) => {
    const server = net.createServer();
    server.unref();
    server.on('error', reject);
    server.listen(0, '127.0.0.1', () => {
      const address = server.address();
      const port = typeof address === 'object' && address ? address.port : 0;
      server.close(() => resolve(port));
    });
  });
}
async function snapshotReports() {
  const entries = (await fs.readdir(reportsRoot, { withFileTypes: true })).filter((entry) => entry.isFile()).map((entry) => entry.name).sort();
  if (JSON.stringify(entries) !== JSON.stringify([...reportFiles].sort())) throw new Error(`报告清单不符:${entries.join(',')}`);
  const snapshot = {};
  for (const name of reportFiles) snapshot[name] = await fs.readFile(path.join(reportsRoot, name), 'utf8');
  return snapshot;
}
async function runPlaywright() {
  const require = createRequire(import.meta.url);
  const packagePath = require.resolve('playwright/package.json');
  const cli = path.join(path.dirname(packagePath), 'cli.js');
  const port = await freePort();
  const run = spawnSync(process.execPath, [cli, 'test', '--config', path.join(outputRoot, 'playwright.config.ts')], {
    cwd: root,
    env: { ...process.env, ALE_INPUT_ROOT: root, ALE_TASK_PORT: String(port) },
    encoding: 'utf8',
    timeout: 120_000
  });
  if (run.status !== 0) throw new Error(`Playwright失败(${run.status ?? 'signal'}):${run.stdout}\n${run.stderr}`);
}

try {
  for (const relative of [...requiredInputs, ...candidateFiles]) if (!await exists(relative)) throw new Error(`缺少必需文件:${relative}`);
  const before = await inputDigest();
  await cleanGenerated();
  await runPlaywright();
  const reports = await snapshotReports();
  const after = await inputDigest();
  if (before !== after) throw new Error('只读输入在运行期间发生变化');
  await fs.rm(artifactsRoot, { recursive: true, force: true });
  console.log(`订阅设置浏览器检查完成，已生成${Object.keys(reports).length}份报告`);
} catch (error) {
  await fs.rm(outputRoot, { recursive: true, force: true });
  await fs.rm(artifactsRoot, { recursive: true, force: true });
  console.error(error instanceof Error ? error.message : String(error));
  process.exitCode = 2;
}
